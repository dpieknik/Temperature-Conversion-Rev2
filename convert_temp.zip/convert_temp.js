"use strict";

//Develop Temperature Converter in the DOM

const $ = selector => document.querySelector(selector);

/*********************
*  helper functions  *
**********************/
const calculateCelsius = temp => (temp-32) * 5/9;			//Celsius Calculation Function
const calculateFahrenheit = temp => temp * 9/5 + 32;		//Fahrenheit Calculation Function

//Swap labels to match desired function, reset focus & clear text and message boxes

const toggleDisplay = (label1Text, label2Text) => {
	$("#degree_label_1").textContent = label1Text;
	$("#degree_label_2").textContent = label2Text;
	$("#degrees_entered").value = "";
	$("#degrees_computed").value = "";
	$("#message").textContent = "";
	$("#degrees_entered").focus();
}

/****************************
*  event handler functions  *
*****************************/
const convertTemp = () => {   
	$("#message").textContent = "";																	//Clear Message Box
	if(isNaN($("#degrees_entered").value)) {														//Error Checking/Display
		$("#message").textContent = "Invalid Entry. Please enter a numeric temperature value.";
	}
	else if($("#to_celsius").checked == true) {															//Calculation carried out based on which radio button is checked
		$("#degrees_computed").value = Math.round(calculateCelsius($("#degrees_entered").value));
	}
	else {
		$("#degrees_computed").value = Math.round(calculateFahrenheit($("#degrees_entered").value));
	}
	
};

const toCelsius = () => toggleDisplay("Enter F degrees:", "Degrees Celsius:");
const toFahrenheit = () => toggleDisplay("Enter C degrees:", "Degrees Fahrenheit:");

document.addEventListener("DOMContentLoaded", () => {
	// add event handlers
	$("#convert").addEventListener("click", convertTemp);
    $("#to_celsius").addEventListener("click", toCelsius);
    $("#to_fahrenheit").addEventListener("click", toFahrenheit);
	
	// move focus
	$("#degrees_entered").focus();
});